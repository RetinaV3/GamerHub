<?php
session_start();
$dbhost = "";
$dbname = "";
$dbpass = "";
$dbdb = "";
$conn = new mysqli($dbhost,$dbname,$dbpass,$dbdb);
if($conn->connect_error){
die("Failed to connect");
}
$get_query = $conn->query("SELECT * FROM users WHERE username='$_SESSION[username]'");
$user_num_query = $conn->query("SELECT * FROM users");
$newest_user_query = $conn->query("SELECT username FROM users ORDER BY id DESC LIMIT 1");
$news_query = $conn->query("SELECT * FROM news ORDER BY id DESC LIMIT 1");
?>