<?php
session_start();
require "database.php";
$username = $_SESSION['username'];
date_default_timezone_set("America/New_York");
$user = $get_query->fetch_assoc();
$user_num = $user_num_query->num_rows;
if($username == "guest"){
session_unset();
session_destroy();
header('location:/index.php');
}
if($user['banned'] == "1"){
header('location:/banned.php');
}
if($user['ipbanned'] == "1"){
header('location:/banned.php');
}
?>