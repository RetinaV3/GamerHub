<html>
<head>
<meta name="viewport" content="width=device-width"/>
<link rel="stylesheet" type="text/css" href="gamerhub.css"/>
</head>
<body align="center">
<div class="banned">
You are banned.
</div>
</body>
</html>