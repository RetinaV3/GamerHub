<?php
require $_SERVER['DOCUMENT_ROOT']."/include/session.php";
?>
<html>
<head>
<meta name="viewport" content="width=device-width"/>
<link rel="stylesheet" type="text/css" href="/gamerhub.css"/>
<link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.css"/>
<title>GamerHub - Edit News</title>
</head>
<body>
<?php include $_SERVER['DOCUMENT_ROOT']."/include/header.php"; ?>
<div class="inner">

</div>
<?php include $_SERVER['DOCUMENT_ROOT']."/include/footer.php"; ?>
</body>
</html>